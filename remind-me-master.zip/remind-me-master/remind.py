from subprocess import call
import time
import sys

notification = sys.argv[1]

# multiplying by 60 to convert minutes to seconds
remind_after = float(sys.argv[2]) * 60

initial_time =  time.time()

while (time.time() - initial_time) < remind_after:
    pass

call(["notify-send", "-t", "10000", "Reminder", notification])
