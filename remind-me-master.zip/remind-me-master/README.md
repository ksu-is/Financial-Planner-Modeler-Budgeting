# remind-me
reminds you whatever you what it to after specified minutes.  
made for learning python,  

**this bash function is better**
`
function r-me()  
{  
  sleep $1; notify-send $2 -t 10000  
}  
`

## usage
* clone the repository 
* add an alias to your .bashrc/.zshrc which runs this program like `alias remindme="python3 ~/remind-me/remind.py"`
* `remindme "Time for workout" 30` to remind you that you have to workout after 30 minutes

## related
**[thirsty.sh](https://github.com/kalbhor/thirsty)**<br/>
reminds you that you are thirsty

## license
GPL-3.0
