import os

from client_reminder_scheduler import main

os.chdir(os.path.dirname(__file__))

if __name__ == "__main__":
    main()
