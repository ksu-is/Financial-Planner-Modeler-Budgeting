# lazada_scraper
Gets search results based from user input and saves into csv file.
