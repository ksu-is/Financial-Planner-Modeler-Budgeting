
# User class
class User:
    def __init__(self, name, surname, email, nip, password):
        self.name = name
        self.surname = surname
        self.email = email
        self.nip = nip
        self.password = password